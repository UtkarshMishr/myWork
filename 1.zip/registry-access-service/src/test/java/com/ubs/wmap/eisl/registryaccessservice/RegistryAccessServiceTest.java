package com.ubs.wmap.eisl.registryaccessservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;
import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;
import com.ubs.wmap.eisl.registryaccessservice.repository.ColumnReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RegistrationRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RoleRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RowReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.service.impl.RegistryReferenceServiceImpl;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.registryaccessservice"})
public class RegistryAccessServiceTest{

    @Mock
    private RegistrationRepository repo;
    @Mock
    private ColumnReferenceRepository columnRefRepo;
    @Mock
    private RowReferenceRepository rowRefRepo;
    @Mock
    private RoleRepository roleRepo;

    @InjectMocks
    private RegistryReferenceServiceImpl registry;

    @Test
    public void getRegistryData() throws RegistryReferenceException {
        Registration reg = new Registration();
        reg.setRegistrationId(1L);
        reg.setServiceId("TestService1");
        reg.setEislToken("abcd");
        reg.setUserId("123");
        reg.setCompany("UBS");
        reg.setDataEntitlement("test");

        Roles roles = new Roles();
        roles.setRoleId(1L);
        roles.setName("TestConsume");

        reg.setRole(roles);

        Set<ColumnReference> columnRef= new HashSet<>();

        ColumnReference colRef = new ColumnReference();
        colRef.setColumnReferenceId(1);
        colRef.setName("name");
        colRef.setJsonModel("test");
        colRef.setProjectionId("1");
        columnRef.add(colRef);

        Set<RowReference> rowRefs= new HashSet<>();

        RowReference rowRef = new RowReference();
        rowRef.setRowReferenceId(1);
        rowRef.setName("reowName");
        rowRef.setRange("rangeType");

        rowRefs.add(rowRef);

        reg.setColumnReferences(columnRef);
        reg.setRowReferences(rowRefs);

        //Mock repo data
        Mockito.when(repo.findByServiceId("TestService1")).thenReturn(reg);

        //Request object
        RegistryAccessRequestVO request = new RegistryAccessRequestVO();
        request.setServiceId("TestService1");

        RegistrationResponseVO registryReference = registry.getRegistryReference(request);

        assertNotNull(registryReference);
        assertEquals("TestService1", registryReference.getServiceId());
        assertEquals("123", registryReference.getUserId());
        assertEquals("abcd", registryReference.getEislToken());
        assertEquals("UBS", registryReference.getCompany());
        assertEquals("test", registryReference.getDataEntitlement());

        RoleResponseVO role = registryReference.getRole();
        assertNotNull(role);

        assertEquals("TestConsume", role.getName());

        Set<ColumnReferenceResponseVO> columnReferences = registryReference.getColumnReferences();
        assertNotNull(columnReferences);
        assertEquals(1, columnReferences.size());
        for (ColumnReferenceResponseVO columnReferenceResponseVO : columnReferences) {
            assertNotNull(columnReferenceResponseVO);
            assertEquals("name", columnReferenceResponseVO.getName());
            assertEquals("test", columnReferenceResponseVO.getJsonModel());
        }

        Set<RowReferenceResponseVO> rowReferences = registryReference.getRowReferences();
        assertNotNull(rowReferences);
        assertEquals(1, rowReferences.size());
        for (RowReferenceResponseVO rowReferenceResponseVO : rowReferences) {
            assertNotNull(rowReferenceResponseVO);
            assertEquals("reowName", rowReferenceResponseVO.getName());
            assertEquals("rangeType", rowReferenceResponseVO.getRange());
        }

        verify(repo, times(1)).findByServiceId("TestService1");
    }

    @Test
    public void saveRegistry() throws RegistryReferenceException {

        //Mock repo data
        Mockito.when(repo.findById(null)).thenReturn(getRegistrationMockedDataById(true));
        Optional<Registration> registrationMockedDataById = getRegistrationMockedDataById(false);
        Mockito.when(repo.save( registrationMockedDataById.get())).thenReturn(getRegistrationMockedDataById(true).get());
        Mockito.when(roleRepo.save( getRoles(false))).thenReturn(getRoles(true));
        Mockito.when(columnRefRepo.save( getColumnReference(false))).thenReturn(getColumnReference(true));
        Mockito.when(rowRefRepo.save( getRowReeference(false))).thenReturn( getRowReeference(true));
        RegistrationResponseVO persistRegistry = registry.persistRegistry(getRegistrationRequestData());
        assertNotNull(persistRegistry);
        //Need to write other assert
    }

    private RegistrationRequestVO getRegistrationRequestData() {
        RegistrationRequestVO registrationRequestVO = new RegistrationRequestVO();
        registrationRequestVO.setCompany("testcomp");
        registrationRequestVO.setDataEntitlement("dataent");
        registrationRequestVO.setEislToken("qbcd");
        registrationRequestVO.setServiceId("TestService1");
        registrationRequestVO.setUserId("testuser");
        registrationRequestVO.setUserName("user");
        RoleRequestVO roleRequestVO = new RoleRequestVO();
        roleRequestVO.setName("TestConsume");
        registrationRequestVO.setRole(roleRequestVO);


        Set<ColumnReferenceRequestVO> columnReferences = new HashSet<>();

        Set<RowReferenceRequestVO> rowReferences = new HashSet<>();

        ColumnReferenceRequestVO columnReferenceRequestVO = new ColumnReferenceRequestVO();
        columnReferenceRequestVO.setName("name");
        columnReferenceRequestVO.setType("type");
        columnReferences.add(columnReferenceRequestVO);

        RowReferenceRequestVO rowReferenceRequestVO = new RowReferenceRequestVO();
        rowReferenceRequestVO.setName("reowName");
        rowReferenceRequestVO.setRange("rangeType");
        rowReferences.add(rowReferenceRequestVO);
        registrationRequestVO.setColumnReferences(columnReferences);
        registrationRequestVO.setRowReferences(rowReferences);

        return registrationRequestVO;
    }
    private Optional<Registration> getRegistrationMockedDataById(boolean isIdRequired) {
        // Request Data
        Registration reg = new Registration();
        Optional<Registration> of = Optional.of(reg);
        reg.setServiceId("TestService1");
        reg.setEislToken("abcd");
        reg.setUserId("123");
        reg.setCompany("UBS");
        reg.setDataEntitlement("test");
        if(isIdRequired) {
            reg.setRegistrationId(1L);
        }
        Roles roles = new Roles();
        roles.setName("TestConsume");
        if(isIdRequired) {
            roles.setRoleId(1L);
        }
        reg.setRole(roles);

        Set<ColumnReference> columnRef = new HashSet<>();

        ColumnReference colRef = new ColumnReference();
        colRef.setName("name");
        colRef.setJsonModel("type");
        if(isIdRequired) {
            colRef.setColumnReferenceId(1);
        }
        columnRef.add(colRef);

        Set<RowReference> rowRefs = new HashSet<>();

        RowReference rowRef = new RowReference();
        if(isIdRequired) {
            rowRef.setRowReferenceId(1);
        }
        rowRef.setName("reowName");
        rowRef.setRange("rangeType");

        rowRefs.add(rowRef);

        reg.setColumnReferences(columnRef);
        reg.setRowReferences(rowRefs);
        return of;
    }

    private Registration getRegistrationAfterSave() {
        Registration reg = new Registration();
        reg.setServiceId("TestService1");
        reg.setEislToken("abcd");
        reg.setUserId("123");
        reg.setCompany("UBS");
        reg.setDataEntitlement("test");
        reg.setRegistrationId(1L);
        return reg;
    }

    private Roles getRoles(boolean isIdRequired) {
        Roles roles = new Roles();
        roles.setName("TestConsume");
        if (isIdRequired) {
            roles.setRoleId(1L);
        }
        return roles;
    }
    private RowReference getRowReeference(boolean isIdRequired) {
        RowReference rowRef = new RowReference();
        if (isIdRequired) {
            rowRef.setRowReferenceId(1);
        }
        rowRef.setName("reowName");
        rowRef.setRange("rangeType");
        return rowRef;
    }
    private ColumnReference getColumnReference(boolean isIdRequired) {
        ColumnReference colRef = new ColumnReference();
        colRef.setName("name");
        colRef.setJsonModel("type");
        if (isIdRequired) {
            colRef.setColumnReferenceId(1);
        }
        return colRef;
    }
}