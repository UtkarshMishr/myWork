package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class RoleResponseVO implements Serializable {

	private static final long serialVersionUID = -1302500552053706652L;

	private Long roleId;

	private String name;

}