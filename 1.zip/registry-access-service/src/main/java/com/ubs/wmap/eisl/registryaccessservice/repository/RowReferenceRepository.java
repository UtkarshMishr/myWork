
package com.ubs.wmap.eisl.registryaccessservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;

@Repository
public interface RowReferenceRepository extends JpaRepository<RowReference, Integer>{

}