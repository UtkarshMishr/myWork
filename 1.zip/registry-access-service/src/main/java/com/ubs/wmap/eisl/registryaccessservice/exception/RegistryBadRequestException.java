package com.ubs.wmap.eisl.registryaccessservice.exception;

public class RegistryBadRequestException extends Exception {
	
	private static final long serialVersionUID = 6583675662971902101L;
	public RegistryBadRequestException(String message) {
		super(message);
	}
	public RegistryBadRequestException(Throwable cause) {
		super(cause);
	}
	public RegistryBadRequestException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
