package com.ubs.wmap.eisl.registryaccessservice.context;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class EislClaimsContext implements Serializable{
	
	private static final long serialVersionUID = 272397852480094863L;
	
	private Map<String, Object> claims;

}
