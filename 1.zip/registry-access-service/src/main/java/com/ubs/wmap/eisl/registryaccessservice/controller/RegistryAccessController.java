package com.ubs.wmap.eisl.registryaccessservice.controller;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContext;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.registryaccessservice.exception.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@CrossOrigin
public class RegistryAccessController{

	private final RegistryReferenceService registryReferenceService;
	
	private final EislClaimsContextUtil eislClaimsContextUtil;
	
	@Value("${app.message.REGISTRY_NOT_FOUND_MSG}")
	private String REGISTRY_NOT_FOUND_MSG;
	
	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${app.message.SERVICE_ID_EMPTY_MESSAGE}")
	private String SERVICE_ID_EMPTY;

	@Value("${app.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;

	@Value("${app.custom.eisl_attribute_name}")
	private String eislClaimsAttribute;

	private final TokenService tokenService;
	
	@GetMapping("/registrations")
	public ResponseEntity<RegistrationResponseVO> getRegistryDetails(@RequestParam("token") String token)
			throws RegistryReferenceException, RegistryAccessBadRequestException, RegistryBadRequestException, InvalidEISLTokenException {
		log.debug("Controller Enetr: Entering getDataReferenceDetails");
		log.debug("token:{}",token);

		//log.info(tokenService.createEILSToken("utk", "TestService1", "admin"));

		if (!servicePreconditions(token).containsKey("claims")) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		}

        String serviceId = (String) eislClaimsContextUtil.getContextParam("serviceId");
        log.debug("serviceId from claim:{}",serviceId);

        if (StringUtils.isEmpty(serviceId)) {
            throw new RegistryBadRequestException(SERVICE_ID_EMPTY);
        }

		RegistrationResponseVO registrationResponse = null;
		try {
			RegistryAccessRequestVO request = new RegistryAccessRequestVO();
			request.setServiceId(serviceId);
			registrationResponse = registryReferenceService.getRegistryReference(request);
			if (null == registrationResponse) {
				log.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new RegistryAccessNotFoundException(REGISTRY_NOT_FOUND_MSG);
			}
		} catch (RegistryReferenceException ex) {
			log.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(registrationResponse);
	}
	
	@PostMapping("/registrations")
	public ResponseEntity<RegistrationResponseVO> postRegistry(@RequestBody RegistrationRequestVO registrationRequestVO,
			@RequestParam("token") String token) throws RegistryReferenceException, InvalidEISLTokenException {
		log.debug("Controller : Entering postRegistry");

		if (!servicePreconditions(token).containsKey("claims")) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		}

		RegistrationResponseVO registrationResponseVO = null;
		try {
			registrationResponseVO = registryReferenceService.persistRegistry(registrationRequestVO);
		} catch (RegistryReferenceException e) {
			log.error( e.getMessage(), e);
			log.debug("Controller : Exiting postRegistry");
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller : Exiting postRegistry");
		return new ResponseEntity<RegistrationResponseVO>(registrationResponseVO, HttpStatus.OK);
	}

	public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEISLTokenException, RegistryReferenceException {
		Map<String, Object> eislClaims;
		try {
			eislClaims = tokenService.init(eislToken);
			createAndSetClaimsInContext(eislClaims);
		} catch (TokenExpireException | TokenUnwrapException ex) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		} catch (RuntimeException rx) {
			log.error(rx.getMessage());
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}

		return  eislClaims;
	}

	private void createAndSetClaimsInContext(Map<String, Object> claims) {
		EislClaimsContext eislClaimsContext = new EislClaimsContext();
		eislClaimsContext.setClaims(claims);
		EislClaimsContextHolder.set(eislClaimsContext);
	}
}
