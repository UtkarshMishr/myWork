package com.ubs.wmap.eisl.registryaccessservice.exception;

public class RegistryAccessNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -7565018735755743641L;
	
	public RegistryAccessNotFoundException(String message) {
		super(message);
	}
	public RegistryAccessNotFoundException(Throwable cause) {
		super(cause);
	}
	public RegistryAccessNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
